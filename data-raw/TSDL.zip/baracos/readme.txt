Some of the data used in "Modeling hydrologic time series from the Arctic"
by P.C. Baracos, K.W. Hipel & A.I. McLeod (1981), Water Resources Bulletin,
Vol. 17, No.3, pp.414-422.

Brief Summary Of The Data Files In The Directory mhsets/baracos

1.  CMINEF.1
TREE RIVER,10QA001, 1969-76, MEAN MONTHLY FLOW                                 

2.  CMINER.1
COPPERMINE, 2200900, MONTHLY, RAIN (MM), 1933-76                               

3.  CMINET.1
COPPERMINE MONTHLY TEMPERATURE,2200900 CELSIUS,1933-1976                       