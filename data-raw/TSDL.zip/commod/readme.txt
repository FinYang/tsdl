This is a file of actual commodity prices of the five
commodities (feeder cattle, gold price, porkbellies, 
soybeans and U.S. treasury bills) on the Chicago
market over a period of about 97-100 consecutive trading days.
For each commodity there are 3 files containing the
daily high, daily low, and daily close price. 

Brief Summary Of The Data Files In The Directory mhsets/commod

1.  FEED.1
FEEDER CATTLE CONTRACTS, CLOSE PRICE ON 95 CONSECUTIVE TRADING DAYS            

2.  FEEDH.1
FEEDER CATTLE APR,81, HIGH                                                     

3.  FEEDL.1
FEEDER CATTLE APR,81, LOW                                                      

4.  GOLD.1
GOLD CLOSE PRICE, 97 SUCCESSIVE TRADING DAYS                                   

5.  GOLDH.1
GOLD JUN,81, HIGH                                                              

6.  GOLDL.1
GOLD JUN,81, LOW                                                               

7.  PORK.1
PORKBELLIES, 99 CONSECUTIVE TRADING DAYS, CLOSE PRICE                          

8.  PORKH.1
PORK BELLIES, HIGH                                                             

9.  PORKL.1
PORK BELLIES MAR,81, LOW                                                       

10.  SOY.1
SOYBEAN CONTRACTS, CLOSE PRICE ON 99 CONSECUTIVE TRADING DAYS                  

11.  SOYH.1
SOYBEANS, HIGH                                                                 

12.  SOYL.1
SOYBEANS, LOW                                                                  

13.  US.1
U.S. TREASURY BILL CONTRACTS, 100 CONSECUTIVE TRADING DAYS                     

14.  USH.1
U.S. T BILLS, HIGH                                                             

15.  USL.1
U.S. TREASURY BILLS MAR,81, LOW                                                





