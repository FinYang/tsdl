Financial time series from "Fractals and Time Series Analysis" by 
R.J. Korsan (1993), Mathematica, Vol.3, pp.39-47

Brief Summary Of The Data Files In The Directory mhsets/korsan

1.  DAILYIBM.1
Daily closing price of IBM stock, Jan 1, 1980 to Oct. 8, 1992                  

2.  DAILYSAP.1
Daily S&P 500 index of stocks, Jan. 1, 1980 to Oct. 8, 1992               