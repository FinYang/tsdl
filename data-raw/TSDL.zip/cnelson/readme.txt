THE DATA SET WAS USED IN 'TRENDS AND RANDOM WALKS IN
MACROECONOMIC TIME SERIES; SOME EVIDENCE AND IMPLICATIONS'
BY CHARLES R. NELSON AND CHARLES I. PLOSSER PUBLISHED IN
JOURNAL OF MONETARY ECONOMICS 10 (1982) P 139-162.
NORTH HOLLAND PUBLISHING COMPANY

Acknowledgment: I would like to thank Charles Nelson for sending
 this data to me via e-mail.

Brief Summary Of The Data Files In The Directory mhsets/cnelson

1.  BND.1
Bond yield, U.S., 1900-1970, annual                                            

2.  CPI.1
CPI, U.S., 1860-1970, annual                                                   

3.  EMP.1
Employment, U.S., 1860-1970, annual                                            

4.  GNP.1
Nominal GNP, U.S., 1909-1970, annual                                           

5.  IP.1
Industrial production, U.S., 1860-1970, annual                                 

6.  M.1
Money Stock, U.S., 1889-1970, annual                                           

7.  PCRGNP.1
Real per capita GNP, U.S., 1909-1970, annual                                   

8.  PRGNP.1
GNP deflator, U.S., 1889-1970, annual                                          

9.  RGNP.1
Real GNP, U.S., 1909-1970, annual                                              

10.  RWG.1
Real wages, U.S., 1900-1970, annual                                            

11.  SP500.1
Common stock prices, U.S., 1871-1970, annual                                   

12.  UN.1
Employment, U.S., 1860-1970, annual                                            

13.  VEL.1
Velocity of money, 1869-1970, annual                                           

14.  WG.1
Wages, U.S., 1900-1970, annual                                                 